import java.util.Scanner;
public class EmployeeDemo {
	public static void main(String[] args) throws Exception {
		Employee[] empArr=new Employee[100]; 
		Scanner scan = new Scanner(System.in);
		int cnt = 0;
		System.out.println("How many Employee you want to enter");
		cnt=scan.nextInt();
		if (cnt>=100) {
			System.out.println("That's too much employee data max is 100 ");
		//exit(0);
		System.exit(0);
	}		
		for (int i=0;i<cnt;i++){
			empArr[i]= new Employee();
			System.out.println("Enter Employee id");
			int empid=scan.nextInt();
			empArr[i].setEmpid(empid);
			System.out.println("Enter Employee Name");
			String name=scan.next();
			empArr[i].setEmpname(name);
			System.out.println("Enter Employee SSN Number");
			String ssn=scan.next();
	
			if(ssn.length()!=11 && !ssn.matches("[--]+")){
				throw new SSNLenghtException("SSN Lenght Should be with two dash(-) Please try Again");
			}
			if(!ssn.matches("[0-9--]+")){
				throw new SSNCharacterException("SNN Should contain Digits (0-9) only Please try Again");
			}
			empArr[i].setSosialSecurityNumber(ssn);
			System.out.println("Enter Employee Salary");
			double salary=scan.nextDouble();
					
			empArr[i].setSalary(salary);
			if (salary >7000) 
				System.out.println(" it's above the average");
			    else 
				System.out.println("it's below the average");
		}
		for (int i=0;i<cnt;i++){
			Employee emp=empArr[i] ;
			
		System.out.println("ID : " + emp.getEmpid() );
		System.out.println( "Name : " + emp.getEmpname() );
		System.out.println( "SSN : " + emp.getSosialSecurityNumber());
		System.out.println( "Salary :  " + emp.getSalary());
		System.out.println();
		System.out.println(" ");
		
		}
		//if (salary >7000){ 
		//	System.out.println(" it's above the average");
		//else 
		//	System.out.println("it's below the average");
		//System.out.println("ID\tName\tSSN\t\tSalary");

		//for (int i=0;i<cnt;i++){
		//	Employee emp=empArr[i] ; 
		//	System.out.print(emp.getEmpid()+"\t"); 
		//	System.out.print(emp.getEmpname()+"\t");
		//	System.out.print(emp.getSosialSecurityNumber()+"\t");
		//	System.out.print(emp.getSalary());
		//	System.out.println();
		//	}
		
	}	
}