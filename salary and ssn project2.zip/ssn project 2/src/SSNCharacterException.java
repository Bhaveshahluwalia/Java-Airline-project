class SSNCharacterException extends Exception {
	private static final long serialVersionUID = 1L;
	private String ssn;		
	public SSNCharacterException(String ssn2) {
		this.ssn=ssn2;
	}
	public String toString() {
		return ssn;
	}

}
