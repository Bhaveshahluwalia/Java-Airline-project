class SSNLenghtException extends Exception {
	private static final long serialVersionUID = 1L;
	private String ssn;
	public SSNLenghtException(String ssn2) {
		this.ssn=ssn2;
	}
	public String toString() {
		return ssn; 
	}
}

